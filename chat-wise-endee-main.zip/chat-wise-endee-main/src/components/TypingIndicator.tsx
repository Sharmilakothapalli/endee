const TypingIndicator = () => (
  <div className="flex items-start gap-3 px-4 py-3">
    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary">
      <span className="text-sm font-semibold text-secondary-foreground">AI</span>
    </div>
    <div className="flex items-center gap-1 rounded-2xl bg-chat-bot px-4 py-3">
      <div className="typing-dot h-2 w-2 rounded-full bg-muted-foreground" />
      <div className="typing-dot h-2 w-2 rounded-full bg-muted-foreground" />
      <div className="typing-dot h-2 w-2 rounded-full bg-muted-foreground" />
    </div>
  </div>
);

export default TypingIndicator;
